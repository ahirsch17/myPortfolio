FROM COMMAND LINE TYPE:
cd sportsPredictor && python -m uvicorn api.server:app --reload --port 8001

FROM FILE EXPLORER:
click sportsPredictor -> web -> index.html (double click)